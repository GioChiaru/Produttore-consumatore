/**
 * 
 */
/**
 * 
 */
module produttore_consumatore {
}